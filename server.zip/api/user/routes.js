var Handlers = require('./handlers');

Routes = 
[
    {
        method: 'POST',
        path:'/login', 
        handler: Handlers.loginHandler,
        config: {
            auth : false
        }
    },

    {
        method: 'GET',
        path:'/logout', 
        handler: Handlers.logoutHandler
    },

    {
        method: 'POST',
        path:'/register', 
        handler: Handlers.registerHandler,
        config: {
            auth : false
        }
    },

    {
        method: 'GET',
        path:'/get_user/{id?}', 
        handler: Handlers.getUserHandler
    },

    {
        method: 'PUT',
        path:'/edit_user/{id}', 
        handler: Handlers.editUserHandler
    },

    {
        method: 'DELETE',
        path:'/delete_user/{id}', 
        handler: Handlers.deleteUserHandler
    },

    {
        method: 'GET',
        path:'/verify_account/{id}/{token}', 
        handler: Handlers.varifyUserHandler,
        config: {
            auth : false
        }
    },

];

module.exports = Routes;