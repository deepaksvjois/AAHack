var md5 		            = require('md5');
var Boom 		            = require('boom');
var promises                = require('bluebird');
const auth_key              = require('../../../config/auth.js');
const connection            = require('../../../config/db.js');
const user_model         = require('../../database/user.js');
const user_auth_model    = require('../../database/user_auth.js');
const audit_model        = require('../../database/audit.js');

var userModel = {};

userModel.user = {};

// Initilize
userModel.initilize = function()
{
    //userModel.validateUser("deepak19891@gmail.com","dee@1989");
}

// Validate user
userModel.validateUser = function (email, password, callback)
{
    password = md5(password);

    user_model.validate_user(email, password)
    .then(function(result) { 

        var response = {"statusCode": "200", "status": "success" , "result" : result, "message" : "user login successful" };
        callback(null, response);

    }).catch(function(error) 
    {
        console.log(error); 
        callback(Boom.unauthorized("invalid username or password"));
    }); 
}

// Validate user
userModel.validateToken = function (token, user_id, callback)
{
    user_auth_model.validate_token(token, user_id)
    .then(function(result) 
    {         
        var result = {"statusCode": "200", "status": "success" , "result" : result, "message" : "user token successful" };
        callback(null, result);

    }).catch(function(error) 
    { 
        console.log(error);
        callback(Boom.unauthorized("invalid token"));
    });     
}

// List user
userModel.getUser = function (user_id, callback)
{    
    if(typeof user_id !== "undefined")
    {
        user_model.get({"user_id" : user_id})
        .then(function(result) 
        {         
            var result = {"statusCode": "200", "status": "success" , "result" : result, "message" : "user list failed" };
            callback(null, result);

        }).catch(function(error) 
        { 
            console.log(error);
            callback(Boom.badRequest("invalid query"));
        });
    }
    else 
    {
        user_model.get_all()
        .then(function(result) 
        {         
            var result = {"statusCode": "200", "status": "success" , "result" : result, "message" : "user list failed" };
            callback(null, result);

        }).catch(function(error) 
        { 
            console.log(error);
            callback(Boom.badRequest("invalid query"));
        });
    }
}

// Create user
userModel.createUser = function (first_name, last_name, email, password, mobile, callback)
{
    password 			    = md5(password);
    let status 			    = "0";
    let create_on 		    = Date.now();
    let audit_id            = "";
    let user_role_id    = "3";

    user_data_validate({"email" : email, "mobile" : mobile}, callback)    
    .then(function()
    {
        audit_data = 
        {
            create_time: create_on,                
        };

        return audit_id =  audit_model.add(audit_data);       
    })
    .then(function(audit_id)
    {
        data = 
        {
            first_name: first_name,
            last_name: last_name,
            email: email,
            password: password,
            mobile: mobile,
            status: status,
            user_role_id: user_role_id,
            audit_id : audit_id
        };

        return user = register_user(data);        
    })
    .then(function(user)
    {
        request_verify_account(user);
        var result = {"statusCode": "201", "status": "success" , "result" : user.user_id, "message" : "register user successful" };
        callback(null, result);
    })
    .catch(function(error) 
    { 
        callback(Boom.badRequest("invalid query"));
    });    
}

// Edit user
userModel.updateUser = function (user_id, first_name, last_name, password, mobile, callback)
{
    where = {"user_id" : user_id};
    data = {
                first_name: first_name,
                last_name: last_name,
                email: email,
                password: password,
                mobile: mobile,                
            };
            
    user_model.update(user_id, first_name, last_name, password, mobile)
    .then(function(result) 
    { 
        var result = {"statusCode": "200", "status": "success" , "result" : user_id, "message" : "user delete successful" };
        callback(null, result);
    })
    .catch(function(error) 
    { 
        console.log(error);
        callback(Boom.badRequest("invalid query"));
    });
}

// Delete user
userModel.deleteUser = function (user_id, callback)
{
    where = {"user_id" : user_id};
    user_model.delete(where)
    .then(function(result) 
    { 
        var result = {"statusCode": "200", "status": "success" , "result" : user_id, "message" : "user delete successful" };
        callback(null, result);
    })
    .catch(function(error) 
    { 
        console.log(error);
        callback(Boom.badRequest("invalid query"));
    });
}

// Varify user account
userModel.verifyUser = function (user_id, token, callback)
{
    return new promises(function(resolve, reject) 
    {
        where = {"user_id" : user_id, "auth_token" : token};
        data = {"status" : "1"};

        user_model.get(where)
        .then(function(result) {
            
            if(result.length > 0)
            {
                user_model.update(where,data) 
                var result = {"statusCode": "200", "status": "success" , "result" : user_id, "message" : "verify user successful" };
                callback(null, result);
            }
            else
            {
                user_model.update(where,data) 
                var result = {"status": "fail" , "result" : "", "message" : "verify user unsuccessful" };
                callback(result);
            }
        })
        .catch(error => 
        {
            console.log(error);
            callback(Boom.badRequest("invalid request"));
        });         
    });
    
}

let register_user = function(data)
{
    return new promises(function(resolve, reject) 
    {
        user_model.add(data)
        .then(result => 
        {        
            resolve(result);
        })
        .catch(error => 
        {
            reject(error);
        });  
    });
}

let user_data_validate = function(where,callback)
{
    return new promises(function(resolve, reject) 
    {
        user_model.get(where)
        .then(result => 
        {     
            if(result.length > 0)
            {
                callback(Boom.badRequest("register failed: email/mobile already in use"));
            } 
            else
            {
                resolve(result);   
            }          
        })
        .catch(error => 
        {
            console.log(error);
            reject(error);
        });  
    });
}

let request_verify_account = function(user)
{
    return new promises(function(resolve, reject) 
    {
        user_model.request_verify_account(user)
        .then(user => 
        {        
            resolve(user_id);
        })
        .catch(error => 
        {
            reject(error);
        });  
    });
}

module.exports = userModel;

