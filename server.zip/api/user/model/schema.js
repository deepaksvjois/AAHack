var Joi 		= require('joi');
const schema 	= {};

schema.login = Joi.object().keys({
	email : Joi.string().email().required(),
	password : Joi.string().max(32).required(),
});

schema.register = Joi.object().keys({
	first_name : Joi.string().max(50).required(),
	last_name : Joi.string().max(50).required(),
	email : Joi.string().email().required(),
	password : Joi.string().max(32).required(),
	mobile : Joi.number().min(10).required(),
});

schema.edit = Joi.object().keys({
	first_name : Joi.string().max(50).required(),
	last_name : Joi.string().max(50).required(),
	password : Joi.string().max(32).required(),
	mobile : Joi.number().min(10).required(),
});

module.exports = schema;