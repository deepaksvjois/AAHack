const jwt           = require('jsonwebtoken');
var Boom 			= require('boom');
var Joi 			= require('joi');
var fs 				= require('fs');
const userStore 	= require('./model/store');
const userSchema 	= require('./model/schema');
const url           = require('../../config/url.js');

var Handlers = {};

// Login
Handlers.loginHandler = function(request , reply)
{
	Joi.validate(request.payload, userSchema.login, function(err, val)
	{
		if(err)
		{
			reply(Boom.unauthorized(err));
		}
		else
		{		
			userStore.validateUser(val.email,val.password, function(err, result)
			{
				if(err)
				{
					return reply(err);
				}
				else
				{		
					return reply(result);
				}
			});			
		}
	});
}

// Register
Handlers.registerHandler = function(request , reply)
{
	Joi.validate(request.payload, userSchema.register, function(err, val)
	{		
		if(err)
		{
			reply(Boom.unauthorized(err));
		}
		else
		{		
			userStore.createUser(val.first_name, val.last_name, val.email, val.password, val.mobile, function(err,result)
			{
				if(err)
				{
					return reply(err);
				}
				else
				{
					return reply(result);
				}				
			});			
		}
	});	
}

// Edit User
Handlers.editUserHandler = function(request , reply)
{
	Joi.validate(request.payload, userSchema.edit, function(err, val)
	{
		if(err)
		{
			reply(Boom.unauthorized(err));
		}
		else
		{	
			var user_id = request.params.id;

			userStore.updateUser(user_id, val.first_name, val.last_name, val.password, val.mobile, function(err,result)
			{
				if(err)
				{
					return reply(err);
				}
				else
				{
					return reply(result);
				}				
			});			
		}
	});	
}

// Delete User
Handlers.deleteUserHandler = function(request , reply)
{
	var user_id = request.params.id;

	if(user_id == "")
	{
		reply(Boom.unauthorized("invalid user"));
	}
	else
	{	
		userStore.deleteUser(user_id, function(err,result)
		{
			if(err)
			{
				return reply(err);
			}
			else
			{
				return reply(result);
			}				
		});			
	}	
}

// Get user list
Handlers.getUserHandler = function(request , reply)
{
	var user_id = request.params.id;

	userStore.getUser(user_id, function(err,result)
	{
		if(err)
		{
			return reply(err);
		}
		else
		{
			return reply(result);
		}				
	});		
}

// Get user list
Handlers.varifyUserHandler = function(request , reply)
{
	var user_id = request.params.id;
	var token 	= request.params.token;

	userStore.verifyUser(user_id, token, function(err,result)
	{
		if(err)
		{
			return reply.redirect(url.client_uri+"/account_verify/fail");
		}
		else
		{
			return reply.redirect(url.client_uri+"/account_verify/success");	
		}				
	});		
}

// Logout
Handlers.logoutHandler = function(request , reply)
{
	var decoded = jwt.decode(request.query.token);
	
	if(decoded.role == "ADMIN" || decoded.role == "SUPER_ADMIN")
	{
		var result = {"status": "success" , "message" : "user logout successful" };
		return reply(result);	
	}
	else
	{
		return reply(Boom.forbidden("invalid user credential"));
	}	
}

module.exports = Handlers;