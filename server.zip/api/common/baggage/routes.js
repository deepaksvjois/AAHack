var Handlers = require('./handlers');

Routes = 
[
    {
        method: 'GET',
        path:'/baggage/{id?}', 
        handler: Handlers.getbaggageHandler
    },

    {
        method: 'POST',
        path:'/baggage', 
        handler: Handlers.createbaggageHandler,
        config: {
            auth : false
        }
    },

    {
        method: 'PUT',
        path:'/baggage/{id}', 
        handler: Handlers.editbaggageHandler
    },

    {
        method: 'DELETE',
        path:'/baggage/{id}', 
        handler: Handlers.deletebaggageHandler
    }

];

module.exports = Routes;