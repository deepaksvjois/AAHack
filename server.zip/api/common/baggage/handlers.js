var Boom 				= require('boom');
var Joi 				= require('joi');
const baggageStore 	= require('./model/store');
const baggageSchema 	= require('./model/schema');

var Handlers = {};

// Create
Handlers.createbaggageHandler = function(request , reply)
{
	Joi.validate(request.payload, baggageSchema.add, function(err, val)
	{
		if(err)
		{
			reply(Boom.unauthorized(err));
		}
		else
		{		
			baggageStore.createbaggage(val.name,val.description, function(err, result)
			{
				if(err)
				{
					return reply(err);
				}
				else
				{		
					return reply(result);
				}
			});			
		}
	});
}

// Edit baggage
Handlers.editbaggageHandler = function(request , reply)
{
	Joi.validate(request.payload, baggageSchema.edit, function(err, val)
	{
		if(err)
		{
			reply(Boom.unauthorized(err));
		}
		else
		{	
			var baggage_id = request.params.id;

			baggageStore.updatebaggage(baggage_id, val.name, val.description, function(err,result)
			{
				if(err)
				{
					return reply(err);
				}
				else
				{
					return reply(result);
				}				
			});			
		}
	});	
}

// Delete baggage
Handlers.deletebaggageHandler = function(request , reply)
{
	var baggage_id = request.params.id;

	if(baggage_id == "")
	{
		reply(Boom.unauthorized("invalid baggage"));
	}
	else
	{	
		baggageStore.deletebaggage(baggage_id, function(err,result)
		{
			if(err)
			{
				return reply(err);
			}
			else
			{
				return reply(result);
			}				
		});			
	}	
}

// Get baggage list
Handlers.getbaggageHandler = function(request , reply)
{
	var baggage_id = request.params.id;

	baggageStore.getbaggage(baggage_id, function(err,result)
	{
		if(err)
		{
			return reply(err);
		}
		else
		{
			return reply(result);
		}				
	});		
}

module.exports = Handlers;