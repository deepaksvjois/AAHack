var Joi 		= require('joi');
const schema 	= {};

schema.add = Joi.object().keys({
	name : Joi.string().min(2).max(200).required(),
	description : Joi.string().max(2000).required(),
});

schema.edit = Joi.object().keys({
	name : Joi.string().min(2).max(200).required(),
	description : Joi.string().max(2000).required(),
});

module.exports = schema;