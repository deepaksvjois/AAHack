var md5 		        = require('md5');
var Boom 		        = require('boom');
var promises            = require('bluebird');
const baggage_model = require('../../../database/baggage.js');
const audit_model    = require('../../../database/audit.js');

var baggageModel = {};

baggageModel.baggage = {};

// List baggage
baggageModel.getbaggage = function (baggage_id, callback)
{    
    if(typeof baggage_id !== "undefined")
    {
        baggage_model.get({"baggage_id" : baggage_id})
        .then(function(result) 
        {         
            var result = {"statusCode": "200", "status": "success" , "result" : result, "message" : "baggage list failed" };
            callback(null, result);

        }).catch(function(error) 
        { 
            console.log(error);
            callback(Boom.badRequest("invalid query"));
        });
    }
    else 
    {
        baggage_model.get_all()
        .then(function(result) 
        {         
            var result = {"statusCode": "200", "status": "success" , "result" : result, "message" : "baggage list failed" };
            callback(null, result);

        }).catch(function(error) 
        { 
            console.log(error);
            callback(Boom.badRequest("invalid query"));
        });
    }
}

// Create baggage
baggageModel.createbaggage = function (name, description, callback)
{
    let create_on 		    = Date.now();
    let audit_id            = "";
    
    baggage_data_validate({"name" : name}, callback)    
    .then(function()
    {
        audit_data = 
        {
            create_time: create_on,                
        };

        return audit_id =  audit_model.add(audit_data);        
    })
    .then(function(audit_id)
    {
        data = 
        {
            name: name,
            description: description,
            audit_id : audit_id
        };

        callback(baggage_model.add(data));
    })
    .catch(function(error) 
    { 
        callback(Boom.badRequest("invalid query"));
    });    
}

// Edit baggage
baggageModel.updatebaggage = function (baggage_id, name, description, callback)
{
    where = {"baggage_id" : baggage_id};
    data = {
                name: name,
                description: description               
            };
            
    baggage_model.update(baggage_id, name, description, password, mobile)
    .then(function(result) 
    { 
        var result = {"statusCode": "200", "status": "success" , "result" : baggage_id, "message" : "baggage delete successful" };
        callback(null, result);
    })
    .catch(function(error) 
    { 
        console.log(error);
        callback(Boom.badRequest("invalid query"));
    });
}

// Delete baggage
baggageModel.deletebaggage = function (baggage_id, callback)
{
    where = {"baggage_id" : baggage_id};
    baggage_model.delete(where)
    .then(function(result) 
    { 
        var result = {"statusCode": "200", "status": "success" , "result" : baggage_id, "message" : "baggage delete successful" };
        callback(null, result);
    })
    .catch(function(error) 
    { 
        console.log(error);
        callback(Boom.badRequest("invalid query"));
    });
}

let baggage_data_validate = function(where,callback)
{
    return new promises(function(resolve, reject) 
    {
        baggage_model.get(where)
        .then(result => 
        {     
            if(result.length > 0)
            {
                callback(Boom.badRequest("register failed: baggage already in available"));
            } 
            else
            {
                resolve(result);   
            }          
        })
        .catch(error => 
        {
            console.log(error);
            reject(error);
        });  
    });
}

module.exports = baggageModel;

