var Handlers = require('./handlers');

Routes = 
[
    {
        method: 'GET',
        path:'/language/{id?}', 
        handler: Handlers.getlanguageHandler,
        config: {
            auth : false
        }
    },

    {
        method: 'POST',
        path:'/language', 
        handler: Handlers.createLanguageHandler,
        config: {
            auth : false
        }
    },

    {
        method: 'PUT',
        path:'/language/{id}', 
        handler: Handlers.editlanguageHandler,
        config: {
            auth : false
        }
    },

    {
        method: 'DELETE',
        path:'/language/{id}', 
        handler: Handlers.deletelanguageHandler,
        config: {
            auth : false
        }
    }

];

module.exports = Routes;