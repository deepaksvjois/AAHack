var Boom 				= require('boom');
var Joi 				= require('joi');
const languageStore 	= require('./model/store');
const languageSchema 	= require('./model/schema');

var Handlers = {};

// Create
Handlers.createLanguageHandler = function(request , reply)
{
	Joi.validate(request.payload, languageSchema.add, function(err, val)
	{
		if(err)
		{
			reply(Boom.unauthorized(err));
		}
		else
		{		
			languageStore.createlanguage(val.name,val.description, function(err, result)
			{
				if(err)
				{
					return reply(err);
				}
				else
				{		
					return reply(result);
				}
			});			
		}
	});
}

// Edit language
Handlers.editlanguageHandler = function(request , reply)
{
	Joi.validate(request.payload, languageSchema.edit, function(err, val)
	{
		if(err)
		{
			reply(Boom.unauthorized(err));
		}
		else
		{	
			var language_id = request.params.id;

			languageStore.updatelanguage(language_id, val.name, val.description, function(err,result)
			{
				if(err)
				{
					return reply(err);
				}
				else
				{
					return reply(result);
				}				
			});			
		}
	});	
}

// Delete language
Handlers.deletelanguageHandler = function(request , reply)
{
	var language_id = request.params.id;

	if(language_id == "")
	{
		reply(Boom.unauthorized("invalid language"));
	}
	else
	{	
		languageStore.deletelanguage(language_id, function(err,result)
		{
			if(err)
			{
				return reply(err);
			}
			else
			{
				return reply(result);
			}				
		});			
	}	
}

// Get language list
Handlers.getlanguageHandler = function(request , reply)
{
	var language_id = request.params.id;

	languageStore.getlanguage(language_id, function(err,result)
	{
		if(err)
		{
			return reply(err);
		}
		else
		{
			return reply(result);
		}				
	});		
}

module.exports = Handlers;