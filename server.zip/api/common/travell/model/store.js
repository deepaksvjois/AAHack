var md5 		        = require('md5');
var Boom 		        = require('boom');
var promises            = require('bluebird');
const language_model = require('../../../database/language.js');
const audit_model    = require('../../../database/audit.js');

var languageModel = {};

languageModel.language = {};

// List language
languageModel.getlanguage = function (language_id, callback)
{    
    if(typeof language_id !== "undefined")
    {
        language_model.get({"language_id" : language_id})
        .then(function(result) 
        {         
            var result = {"statusCode": "200", "status": "success" , "result" : result, "message" : "language list success" };
            callback(null, result);

        }).catch(function(error) 
        { 
            console.log(error);
            callback(Boom.badRequest("invalid query"));
        });
    }
    else 
    {
        language_model.get_all()
        .then(function(result) 
        {         
            var result = {"statusCode": "200", "status": "success" , "result" : result, "message" : "language list failed" };
            callback(null, result);

        }).catch(function(error) 
        { 
            console.log(error);
            callback(Boom.badRequest("invalid query"));
        });
    }
}

// Create language
languageModel.createlanguage = function (name, description, callback)
{
    let create_on 		    = Date.now();
    let audit_id            = "";
    
    language_data_validate({"name" : name}, callback)    
    .then(function()
    {
        audit_data = 
        {
            create_time: create_on,                
        };

        return audit_id =  audit_model.add(audit_data);        
    })
    .then(function(audit_id)
    {
        data = 
        {
            name: name,
            description: description,
            audit_id : audit_id
        };

        callback(language_model.add(data));     
    })
    .catch(function(error) 
    { 
        callback(Boom.badRequest("invalid query"));
    });    
}

// Edit language
languageModel.updatelanguage = function (language_id, name, description, callback)
{
    where = {"language_id" : language_id};
    data = {
                name: name,
                description: description               
            };
            
    language_model.update(language_id, name, description, password, mobile)
    .then(function(result) 
    { 
        var result = {"statusCode": "200", "status": "success" , "result" : language_id, "message" : "language delete successful" };
        callback(null, result);
    })
    .catch(function(error) 
    { 
        console.log(error);
        callback(Boom.badRequest("invalid query"));
    });
}

// Delete language
languageModel.deletelanguage = function (language_id, callback)
{
    where = {"language_id" : language_id};
    language_model.delete(where)
    .then(function(result) 
    { 
        var result = {"statusCode": "200", "status": "success" , "result" : language_id, "message" : "language delete successful" };
        callback(null, result);
    })
    .catch(function(error) 
    { 
        console.log(error);
        callback(Boom.badRequest("invalid query"));
    });
}

let language_data_validate = function(where,callback)
{
    return new promises(function(resolve, reject) 
    {
        language_model.get(where)
        .then(result => 
        {     
            if(result.length > 0)
            {
                callback(Boom.badRequest("register failed: language already in available"));
            } 
            else
            {
                resolve(result);   
            }          
        })
        .catch(error => 
        {
            console.log(error);
            reject(error);
        });  
    });
}

module.exports = languageModel;

