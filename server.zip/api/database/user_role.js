var Boom 			= require('boom');
var promises        = require('bluebird');
var sequelize	    = require('sequelize');
const jwt           = require('jsonwebtoken');
const auth_key      = require('../../config/auth.js');
const connection    = require('../../config/db.js');
const Op            = sequelize.Op;

var user_role_model = {};

// Table defination
table_user_role = connection.define('user_role', 
{
    user_role_id: 
    {
        type: sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    name: sequelize.STRING,
    description: sequelize.STRING,
    privilege_group_id: sequelize.INTEGER,
    audit_id: sequelize.INTEGER,
});

// Get all user
user_role_model.get_all = function() 
{
    return new promises(function(resolve, reject) 
    {
        table_user_role.findAll()
        .then(roles => 
        {
            resolve(roles);
        })
        .error(err => 
        {
            reject(err);
        });
    });  
}

// Get individual user
user_role_model.get = function(where) 
{
    return new promises(function(resolve, reject) 
    {
        table_user_role.findAll(
        {  
            where: { [Op.and]: [where] },
        })
        .then(roles => 
        {
            resolve(roles);
        })
        .error(err => 
        {
            reject(err);
        });
    });      
}

// Register User
user_role_model.add = function(data) 
{
    return new promises(function(resolve, reject) 
    {    
        table_user_role.create(
        data,
        {
            raw: false
        })
        .then(result =>
        {
            resolve(result.dataValues);
        })
        .error(err =>
        {
            reject(err);
        });
    });  
}

// Update user
user_role_model.update = function(where, data) 
{
    var update_on = Date.now();

    return new promises(function(resolve, reject) 
    {    
        table_user_role.update
        (
            data,
            { where: where}
        )
        .then(result =>
            resolve(result)
        )
        .error(err =>
            reject(err)
        );
    });
}

// Delete user
user_role_model.delete = function(where) {

    return new promises(function(resolve, reject) {
        
        table_user.destroy({
            where: where
        })
        .then(result => 
        {
            resolve(result)
        })
        .catch(err =>
        {
            reject(err);
        })
    });
}

module.exports = user_role_model;