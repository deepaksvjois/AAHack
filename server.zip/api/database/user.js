var mail            = require('nodemailer');
var md5 		    = require('md5');
var Boom 			= require('boom');
var promises        = require('bluebird');
var sequelize	    = require('sequelize');
var DataTypes       = require('sequelize/lib/data-types');
const jwt           = require('jsonwebtoken');
const auth_key      = require('../../config/auth.js');
const connection    = require('../../config/db.js');
const url           = require('../../config/url.js');
const Op            = sequelize.Op;

const user_auth_model     = require('./user_auth.js');
const user_role_model     = require('./user_role.js');

// Table defination
table_user = connection.define('user', 
{
    user_id: 
    {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    first_name: DataTypes.STRING,
    last_name: DataTypes.STRING,
    email: DataTypes.STRING,
    password: DataTypes.STRING,
    mobile: DataTypes.STRING,
    gender: DataTypes.STRING,
    dob: DataTypes.STRING,
    status: DataTypes.INTEGER,
    user_role_id: DataTypes.INTEGER,
    auth_token: DataTypes.STRING,
    user_role_id: DataTypes.INTEGER,
    audit_id: DataTypes.INTEGER,
});


var user_model = {};

// Get all user
user_model.get_all = function() 
{
    return new promises(function(resolve, reject) 
    {
        table_user.findAll()
        .then(users => 
        {
            resolve(users);
        })
        .error(err => 
        {
            reject(err);
        });
    });  
}

// Get individual user
user_model.get = function(where) 
{
    return new promises(function(resolve, reject) 
    {
        table_user.findAll(
        {  
            where: { [Op.and]: [where] },
        })
        .then(users => 
        {
            console.log(users);   
            resolve(users);
        })
        .error(err => 
        {
            reject(err);
        });
    });      
}

// Get individual user
user_model.get_or = function(where) 
{
    return new promises(function(resolve, reject) 
    {
        table_user.findAll(
        {  
            where: { [Op.or]: [where] },
        })
        .then(users => 
        {
            console.log(users);   
            resolve(users);
        })
        .error(err => 
        {
            reject(err);
        });
    });      
}

// Register User
user_model.add = function(data) 
{
    return new promises(function(resolve, reject) 
    {    
        table_user.create(
        data,
        {
            raw: false
        })
        .then(result =>
        {
            resolve(result.dataValues);
        })
        .error(err =>
        {
            reject(err);
        });
    });  
}

// Update user
user_model.update = function(where, data) 
{
    var update_on = Date.now();

    return new promises(function(resolve, reject) 
    {    
        table_user.update
        (
            data,
            { where: where}
        )
        .then(result =>
            resolve(result)
        )
        .error(err =>
            reject(err)
        );
    });
}

// Delete user
user_model.delete = function(where) {

    return new promises(function(resolve, reject) {
        
        table_user.destroy({
            where: where
        })
        .then(result => 
        {
            resolve(result)
        })
        .catch(err =>
        {
            reject(err);
        })
    });
}

// Validate user
user_model.validate_user = function(email, password, dob) 
{
    return new promises(function(resolve, reject) 
    {
        table_user.findAll(
            {
                where: {
                    [Op.and]: [{"email": email , "password": password , "status": "1"}]
                },
            }
        )
        .then(users => 
        {
            if(users.length > 0)
            {         
                where = {"user_role_id" : users[0].user_role_id};
                let role       = user_role_model.get(where);  

                user_role_model.get(where)
                .then(role => 
                {
                    var user        = { "uid" : users[0].user_id, "role": role[0]["name"], "name": users[0].first_name + " "+ users[0].last_name};
                
                    var token       = user_auth_model.create_token(user);
                    var user_info   = { "id" : users[0].user_id, "email": users[0].email, "first_name": users[0].first_name , "last_name": users[0].last_name , "token": token };

                    var decoded = jwt.decode(token);

                    data = {
                        "user_id" : users[0].user_id,
                        "auth_token" : token,
                        "create_time" : decoded.iat,
                        "expiry_time" : decoded.exp,
                    };

                    user_auth_model.add(data);

                    resolve(user_info);
                });
            }
            else
            {
                reject("invalid credentials");
            }
        })
        .error(err => 
            {
                reject(err);
            }
        );
    });
}

// Update user
user_model.request_verify_account = function(user) 
{
    return new promises(function(resolve, reject) 
    {     
        var token = md5(user.user_id + user.email + Date.now()); 
        user.token = token;
        send_mail(user);        

        return table_user.update(
            { auth_token: token },
            { where: { user_id: user.user_id }}
        );
    });
}

// Send mail
let send_mail = function(data)
{
    return new promises(function(resolve, reject) 
    { 
        /*let selfSignedConfig = {
            host: 'smtp.office365.com',
            port: 587,
            secure: false,
            auth: {
                user: 'deepaksvjois@riversilica.com',
                pass: 'deepak@1989'
            }
        };*/

        let selfSignedConfig = {
            host: 'smtp.gmail.com',
            port: 587,
            secure: false,
            auth: {
                user: 'deepaksvjois@gmail.com',
                pass: 'dee@1989'
            }
        };
        
        var reset_url = url.server_uri + "/verify_account/"+data.user_id+"/"+data.token;
        var content = "All you need to do is click the button below (it only takes a few seconds). You won’t be asked to log in to your tg account – we are simply verifying ownership of this email address.";
        content = content + "<span style='font-size : 14px;'> <a href='"+reset_url+"'> Click Here </a> </span>. <br /><br />"

        // create reusable transporter object using the default SMTP transport
        let transporter = mail.createTransport(selfSignedConfig);

        // setup email data with unicode symbols
        let mailOptions = {
            from: '"admin@tg.com" <deepaksvjois@riversilica.com>',
            to: data.email,
            subject: 'Action required: Please verify your email address',
            html: content
        };

        // send mail with defined transport object
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return console.log(error);
            }
            console.log('Message %s sent: %s', info.messageId, info.response);
        });
    });
}

module.exports = user_model;