var Boom 			= require('boom');
var promises        = require('bluebird');
var sequelize	    = require('sequelize');
const jwt           = require('jsonwebtoken');

const auth_key      = require('../../config/auth.js');
const connection    = require('../../config/db.js');
const Op            = sequelize.Op;

// Table defination
table_baggage = connection.define('baggage', 
{
    baggage_id: 
    {
        type: sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    name: sequelize.STRING,
    description: sequelize.STRING,
    audit_id: sequelize.INTEGER,
});


var baggage_model = {};

// Get all baggage
baggage_model.get_all = function() 
{
    return new promises(function(resolve, reject) 
    {
        table_baggage.findAll()
        .then(users => 
            {
                resolve(users);
            }            
        )
        .error(err => 
            {
                reject(err);
            }
        );
    });  
}

// Get individual user
baggage_model.get = function(where) 
{
    return new promises(function(resolve, reject) 
    {
        table_baggage.findAll(
        {  
            where: {
                [Op.and]: [where]
            },
        })
        .then(users => 
        {
            resolve(users);
        })
        .error(err => 
        {
            reject(err);
        });
    });      
}

// Add baggage
baggage_model.add = function(data) 
{
    return new promises(function(resolve, reject) 
    {    
        table_baggage.create
        (
            data            
        )
        .then(result =>
        {            
            resolve(result.dataValues.baggage_id);
        })
        .error(err =>
        {
            console.log(err);
            reject(err);
        });
    });  
}

baggage_model.delete = function(where) {

    return new promises(function(resolve, reject) {
        
        table_baggage.destroy({
            where: where
        })
        .then(result => 
        {
            resolve(result)
        })
        .catch(err =>
        {
            reject(err);
        })
    });
}

module.exports = baggage_model;