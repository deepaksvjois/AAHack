var Boom 			= require('boom');
var promises        = require('bluebird');
var sequelize	    = require('sequelize');
const jwt           = require('jsonwebtoken');

const auth_key      = require('../../config/auth.js');
const connection    = require('../../config/db.js');
const Op            = sequelize.Op;

// Table defination
table_language = connection.define('language', 
{
    language_id: 
    {
        type: sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    name: sequelize.STRING,
    description: sequelize.STRING,
    audit_id: sequelize.INTEGER,
});


var language_model = {};

// Get all language
language_model.get_all = function() 
{
    return new promises(function(resolve, reject) 
    {
        table_language.findAll()
        .then(users => 
            {
                resolve(users);
            }            
        )
        .error(err => 
            {
                reject(err);
            }
        );
    });  
}

// Get individual user
language_model.get = function(where) 
{
    return new promises(function(resolve, reject) 
    {
        table_language.findAll(
        {  
            where: {
                [Op.and]: [where]
            },
        })
        .then(users => 
        {
            resolve(users);
        })
        .error(err => 
        {
            reject(err);
        });
    });      
}

// Add language
language_model.add = function(data) 
{
    return new promises(function(resolve, reject) 
    {    
        table_language.create
        (
            data            
        )
        .then(result =>
        {            
            resolve(result.dataValues.language_id);
        })
        .error(err =>
        {
            console.log(err);
            reject(err);
        });
    });  
}

language_model.delete = function(where) {

    return new promises(function(resolve, reject) {

        table_language.destroy({
            where: where
        })
        .then(result => 
        {
            resolve(result)
        })
        .catch(err =>
        {
            reject(err);
        })
    });
}

module.exports = language_model;