var Boom 			= require('boom');
var promises        = require('bluebird');
var sequelize	    = require('sequelize');
const jwt           = require('jsonwebtoken');
const auth_key      = require('../../config/auth.js');
const connection    = require('../../config/db.js');
const Op            = sequelize.Op;

var user_auth_model = {};

// Table defination
table_user_auth = connection.define('user_auth', 
{
    user_auth_id: 
    {
        type: sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    user_id: sequelize.INTEGER,
    auth_token: sequelize.STRING,
    create_time: sequelize.INTEGER,
    expiry_time: sequelize.INTEGER,
});

user_auth_model.get_all = function() 
{
    
}

user_auth_model.get = function(where) 
{
      
}

user_auth_model.add = function(data) 
{
    return new promises(function(resolve, reject) 
    {    
        table_user_auth.create
        (
            data,
            {
                raw: false
            }
        )
        .then(result =>
        {
            resolve(result.dataValues.user_auth_id);
        })
        .error(err =>
        {
            reject(err);
        }            
        );
    });  
}

user_auth_model.update = function(data, where) 
{
    
}

user_auth_model.delete = function(where) 
{
    user_auth_model.destroy({
        where: where
    })
    .then(result => 
    {
        resolve(result)
    })
    .catch(err =>
    {
        reject(err);
    })   
}

user_auth_model.validate_token = function(token, user_id, dob) 
{
    return new promises(function(resolve, reject) 
    {
        table_user_auth.findAll(
            {
                where: {
                    [Op.and]: [{"auth_token": token}, {"user_id": user_id}]
                },
            }
        )
        .then(result => 
            {
                if(result.length > 0)
                {               
                    resolve(result);
                }
                else
                {
                    reject(Boom.unauthorized("invalid Credentials"));
                }
            }            
        )
        .error(err => 
            {
                reject(err);
            }
        );
    });
}

user_auth_model.create_token = function(user) 
{  
    return jwt.sign(user, auth_key, { algorithm: 'HS256', expiresIn: "2h" } );
}

module.exports = user_auth_model;