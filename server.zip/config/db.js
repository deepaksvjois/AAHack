var sequelize	= require('sequelize');

const connection = new sequelize('travell', 'root', '', {
        host: 'localhost',
        dialect: 'mysql',
        define: {
            timestamps: false,
            freezeTableName: true,
            operatorsAliases: false
        },
        query:{raw:true}
    });

module.exports = connection;