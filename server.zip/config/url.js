var url = {
    "server_uri"    : "http://localhost:8080",
    "client_uri"    : "http://localhost",    
    "admin_uri"     : "http://localhost",
    "port"          : "8000",
};

module.exports = url;