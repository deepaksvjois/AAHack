const key = '7ec0dc55ffcc81e395db823312b8eacee81957e0'; //GuRuT@lEnT

module.exports = key;